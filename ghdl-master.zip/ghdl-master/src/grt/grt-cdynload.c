#if defined(__WIN32__)
#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

void *
grt_dynload_open (const char *path)
{
  return (void *)LoadLibrary (path);
}

void *
grt_dynload_symbol (void *handle, const char *symbol)
{
  return (void *)GetProcAddress ((HMODULE)handle, symbol);
}

const char *
grt_dynload_error (void)
{
  static char msg[256];

  FormatMessage
    (FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
     NULL,
     GetLastError (),
     MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
     (LPTSTR) &msg,
     sizeof (msg) - 1,
     NULL);
  return msg;
}

#ifdef __cplusplus
}
#endif

#else

#include <dlfcn.h>

#ifdef __cplusplus
extern "C" {
#endif

void *
grt_dynload_open (const char *path)
{
  return dlopen (path, RTLD_LAZY);
}

void *
grt_dynload_symbol (void *handle, const char *symbol)
{
  return dlsym (handle, symbol);
}

const char *
grt_dynload_error (void)
{
  return dlerror ();
}

#ifdef __cplusplus
}
#endif
#endif

#! /bin/sh

. ../../testenv.sh

analyze_failure crash.vhd

clean

echo "Test successful"

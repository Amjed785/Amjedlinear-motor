#! /bin/sh

. ../../testenv.sh

analyze_failure module.vhd

clean

echo "Test successful"

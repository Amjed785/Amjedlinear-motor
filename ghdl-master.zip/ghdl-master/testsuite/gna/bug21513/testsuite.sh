#! /bin/sh

. ../../testenv.sh


analyze pb.vhdl

clean

echo "Test successful"

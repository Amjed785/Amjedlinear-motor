#! /bin/sh

. ../../testenv.sh

analyze_failure bug.vhdl

clean

echo "Test successful"

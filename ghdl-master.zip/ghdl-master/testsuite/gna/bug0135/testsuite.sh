#! /bin/sh

. ../../testenv.sh

analyze_failure err3_top.vhdl

clean

echo "Test successful"

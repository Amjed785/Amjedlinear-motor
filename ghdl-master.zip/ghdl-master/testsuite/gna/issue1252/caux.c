int getInt(){return 1;};


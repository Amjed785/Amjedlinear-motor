#! /bin/sh

. ../../testenv.sh

analyze_failure 573721_deb.vhd

clean

echo "Test successful"

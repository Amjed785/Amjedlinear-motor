#! /bin/sh

. ../../testenv.sh

analyze cic_up.vhd

clean

echo "Test successful"

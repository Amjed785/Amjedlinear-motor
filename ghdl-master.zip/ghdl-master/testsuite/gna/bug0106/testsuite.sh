#! /bin/sh

. ../../testenv.sh

analyze_failure repro.vhdl

clean

echo "Test successful"

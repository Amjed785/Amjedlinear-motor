#! /bin/sh

. ../../testenv.sh

analyze -fpsl issue.vhdl

clean

echo "Test successful"

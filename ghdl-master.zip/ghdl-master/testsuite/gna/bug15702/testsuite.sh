#! /bin/sh

. ../../testenv.sh

analyze_failure example.vhd

clean

echo "Test successful"
